# SOUQI MARKET — بنية التشغيل

GitHub (المصدر الرئيسي)
        │
        ▼
GitHub Actions
  │ اختبار
  │ Backup Tag + Artifact
  ▼
Production Hosting
  ├── Frontend
  └── Backend Node.js
        │
        ▼
PostgreSQL

الدفع الحقيقي يبقى Server-to-Server، ومفاتيح Qi لا تصل إلى المتصفح.
