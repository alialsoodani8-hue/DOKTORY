# قائمة الربط بالاستضافة — SOUQI MARKET

### قبل الربط
- [ ] مستودع GitHub خاص بالمشروع.
- [ ] فرع `main` هو النسخة المستقرة.
- [ ] قاعدة PostgreSQL جاهزة.
- [ ] Backend يعمل على Node.js 20+.
- [ ] Frontend يوجه `/admin/` إلى بوابة الإدارة.

### متغيرات Backend
- `PORT`
- `DATABASE_URL`
- `JWT_SECRET`
- `FRONTEND_URL`
- `COOKIE_SECURE=true`
- مفاتيح الدفع الحقيقية توضع في Secrets الخاصة بالاستضافة فقط.

### بعد الربط
1. شغّل `/api/health` وتأكد من `ok: true`.
2. نفّذ `backend/schema.sql` على قاعدة PostgreSQL.
3. أنشئ حساب OWNER بطريقة آمنة خارج الواجهة العامة.
4. اختبر تسجيل الدخول إلى `/admin/`.
5. اختبر الصلاحيات لكل دور.
6. نفّذ عملية دفع اختبارية قبل تفعيل الإنتاج.
7. فعّل Deploy Hook أو GitHub Integration.
8. اختبر النسخ الاحتياطي والرجوع للخلف قبل الإطلاق التجاري.

## V8 — فحص ما قبل الإطلاق
- [ ] ضبط `NODE_ENV=production` و`COOKIE_SECURE=true`.
- [ ] وضع `DATABASE_URL` و`SESSION_SECRET` و`ENCRYPTION_KEY` في Secrets الخاصة بالاستضافة.
- [ ] تشغيل `npm run check` ثم `npm run smoke:test`.
- [ ] تطبيق `schema.sql` على PostgreSQL.
- [ ] تشغيل `npm run setup:admin` مرة واحدة وحفظ بيانات المالك خارج المشروع.
- [ ] ربط HTTPS والدومين.
- [ ] ضبط `TRUST_PROXY` وفق مزود الاستضافة.
- [ ] اختبار `/api/health` و`/api/ready` بعد النشر.
- [ ] تفعيل نسخ PostgreSQL الاحتياطية واختبار الاسترجاع قبل الإطلاق.
- [ ] عدم وضع أي مفتاح Qi أو مفتاح دفع في الواجهة أو GitHub.
