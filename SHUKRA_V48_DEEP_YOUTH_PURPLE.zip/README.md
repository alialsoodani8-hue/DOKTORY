# SOUQI | سوكي — Global Marketplace

منصة **SOUQI | سوكي** العالمية للبيع والشراء والإعلانات والخدمات، مع واجهة عربية RTL قابلة للتوسع إلى الإنجليزية واللغات الأخرى.

> هذا المستودع هو نقطة انطلاق تطويرية جاهزة للرفع إلى GitHub. مفاتيح الدفع وكلمات المرور وملفات `.env` الحقيقية غير مضمنة.

## ما الموجود فعلياً؟

- Frontend: HTML5 + CSS3 + JavaScript.
- Backend: Node.js 20+ + Express 5.
- Database: PostgreSQL 16.
- Admin/Owner: تسجيل دخول، RBAC، جلسات HttpOnly، CSRF، TOTP 2FA، Audit Log.
- Payments: مسار Qi API فعلي في Backend، مع سجل بوابات إضافية قابلة للتفعيل بعد التعاقد والاعتماد.
- Security: Helmet، rate limiting أساسي، scrypt، AES-256-GCM، HMAC، تحقق TOTP، حماية رفع الملفات، وسجل أحداث أمني.
- PWA: Web Manifest + Service Worker + icons.
- DevOps: Docker Compose + GitHub Actions للاختبار والنسخ الاحتياطي وDeploy Hooks الاختيارية.

## تشغيل سريع

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
# عدّل DATABASE_URL وSESSION_SECRET وENCRYPTION_KEY وبقية الأسرار
npm run check
npm start
```

### 2. PostgreSQL

يمكن تشغيل PostgreSQL محلياً عبر:

```bash
docker compose -f docker-compose.postgres.yml up -d
```

ثم طبّق `backend/schema.sql` ومهاجرات `backend/migrate_*.sql` حسب الإصدار المطلوب.

### 3. الواجهة

افتح `index.html` عبر خادم static محلي. في الإنتاج يجب أن تكون الواجهة والـBackend خلف HTTPS وأن تكون `FRONTEND_URL` و`PUBLIC_BASE_URL` صحيحتين.

## GitHub

1. أنشئ مستودعاً جديداً باسم مثل `SOUQI-MARKET`.
2. ارفع **محتويات هذا المجلد** إلى جذر المستودع.
3. لا ترفع `.env` أو مفاتيح Qi أو كلمات مرور الإدارة.
4. فعّل GitHub Actions.
5. أضف Secrets الخاصة بالاستضافة فقط إذا أردت النشر التلقائي.

التفاصيل الكاملة في `docs/GITHUB_UPLOAD_AR.md`.

## ملاحظة الدفع

Qi هو مسار الدفع العراقي المطبق برمجياً في هذه النسخة، بينما بقية مزودي الدفع موجودون كبنية توجيه/إعداد وقابلية توسع ولا يجب عرضهم كخدمات حية قبل إكمال عقد التاجر، الاعتماد، مفاتيح API، Webhooks والتسوية المالية.

## الأمان

لا يوجد نظام برمجي يضمن حماية 100%. SOUQI مبني على دفاع متعدد الطبقات، ويحتاج في الإنتاج إلى WAF/CDN، TLS، جدار ناري، قاعدة بيانات غير مكشوفة للإنترنت، نسخ احتياطية مشفرة، Secret Manager ومراقبة مستمرة.

## وثائق المشروع

- `docs/TECH_STACK.md` — اللغات والبرمجيات والتقنيات.
- `docs/PROJECT_STRUCTURE.md` — شرح الملفات والمجلدات.
- `docs/SETUP_AR.md` — التشغيل المحلي خطوة بخطوة.
- `docs/GITHUB_UPLOAD_AR.md` — تجهيز ورفع المشروع إلى GitHub.
- `docs/PAYMENT_ARCHITECTURE.md` — بنية الدفع الحالية وخطة التوسع.
- `docs/SECURITY_ARCHITECTURE.md` — طبقات الحماية.
- `docs/DEPLOYMENT.md` — متطلبات النشر والإنتاج.
- `docs/CHANGELOG.md` — سجل الإصدارات والتعديلات.
