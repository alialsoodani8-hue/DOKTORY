# SOUQI MARKET V44 — Bank card showcase removed

- Removed the visible bank/payment card image showcase from the public homepage.
- Kept the secure payment backend architecture and Qi integration code unchanged.
- Payment provider configuration remains server-side; removing an image does not disable payment APIs.
- Project stack: HTML5, CSS3, vanilla JavaScript frontend; Node.js + Express backend; PostgreSQL database; PWA manifest/service worker.
