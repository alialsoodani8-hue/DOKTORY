# SOUQI — بنية المشروع

```text
SOUQI_MARKET/
├─ index.html                 # الواجهة الرئيسية
├─ admin/index.html           # بوابة الإدارة
├─ icons/                     # شعارات وأيقونات PWA
├─ manifest.webmanifest       # تعريف PWA
├─ sw.js                      # Service Worker
├─ backend/
│  ├─ package.json            # Backend dependencies/scripts
│  ├─ .env.example            # قالب متغيرات البيئة
│  ├─ schema.sql              # PostgreSQL schema
│  ├─ migrate_*.sql           # migrations
│  ├─ src/server.js           # Express API + auth + payments
│  ├─ src/security.js         # hashing / TOTP / encryption / tokens
│  └─ scripts/                # setup + migration + smoke tests
├─ docs/                      # وثائق التطوير والتشغيل
├─ ops/                       # التشغيل والاستضافة والتحديث
├─ .github/workflows/         # CI/CD
└─ docker-compose.postgres.yml
```

## قاعدة مهمة
ملف `.env` الحقيقي لا يدخل Git. يتم استخدام `.env.example` فقط كقالب.
