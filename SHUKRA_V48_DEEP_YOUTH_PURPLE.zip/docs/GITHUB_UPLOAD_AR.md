# SOUQI — رفع المشروع إلى GitHub

## قبل الرفع

تأكد من عدم وجود:

- `.env`
- مفاتيح Qi الخاصة
- كلمات مرور
- مفاتيح تشفير حقيقية
- Tokens أو API keys
- ملفات `node_modules`

## إنشاء المستودع

أنشئ Repository جديداً، ثم من مجلد SOUQI:

```bash
git init
git branch -M main
git add .
git commit -m "Initial SOUQI marketplace platform"
git remote add origin <YOUR_GITHUB_REPOSITORY>
git push -u origin main
```

استبدل `<YOUR_GITHUB_REPOSITORY>` برابط مستودعك الفعلي.

## GitHub Actions

الملف:

`.github/workflows/ci-cd.yml`

يقوم بفحص JavaScript والملفات الأساسية، وينشئ Artifact، ويمكنه إنشاء backup tag وتشغيل Deploy Hooks اختيارية.

## Secrets

أضف أسرار الإنتاج من إعدادات GitHub/مزود الاستضافة، ولا تكتبها داخل الملفات المصدرية.
