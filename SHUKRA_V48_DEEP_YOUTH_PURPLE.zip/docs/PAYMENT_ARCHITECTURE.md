# SOUQI — بنية الدفع

## المسار المطبق حالياً

**Qi** هو مسار الدفع العراقي المطبق برمجياً في Backend.

العملية:

1. إنشاء طلب دفع من الإعلان.
2. إنشاء Payment Request لدى Qi بتوقيع RSA-SHA256.
3. حفظ سجل المعاملة في PostgreSQL.
4. حالات المعاملة: `SUCCESS` / `PENDING` / `FAIL`.
5. عند النجاح يتم نشر الإعلان وفق منطق Backend.
6. إشعار Qi يرجع إلى Webhook في Backend.

## مزودون قابلون للتوسع

يوجد Provider Registry في الكود لبوابات مثل ZainCash وFIB وFastPay وCard Gateway، لكن وجود اسم المزود في registry لا يعني أن الحساب التجاري أو API حي.

قبل تفعيل أي مزود يجب توفير:

- عقد Merchant رسمي.
- API credentials.
- Webhook verification.
- Settlement configuration.
- متطلبات الامتثال والترخيص الخاصة بالدولة.

## حماية الأسرار

كل مفاتيح الدفع تبقى في Backend environment / secret manager. لا توضع في HTML أو JavaScript العام.
