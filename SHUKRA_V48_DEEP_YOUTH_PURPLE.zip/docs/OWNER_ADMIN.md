# SOUQI — Owner & Admin

- OWNER: الإدارة العليا وإدارة الموظفين.
- ADMIN: صلاحيات الإدارة الممنوحة.
- FINANCE: صلاحيات مالية حسب RBAC.
- OPERATIONS: تشغيل ومراجعة المحتوى.
- SUPPORT: دعم المستخدمين.

الجلسات تستخدم HttpOnly cookies، والتغييرات الحساسة تتطلب CSRF token. 2FA مبني على TOTP.

لا تحفظ بيانات دخول Owner داخل GitHub. استخدم Secret Manager أو مدير كلمات مرور.
