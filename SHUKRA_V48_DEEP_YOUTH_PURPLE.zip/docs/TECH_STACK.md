# SOUQI — التقنيات والبرمجيات المستخدمة

## Frontend
- HTML5
- CSS3
- Vanilla JavaScript / ECMAScript
- Responsive UI
- RTL Arabic layout
- Web Manifest
- Service Worker
- PWA icons

## Backend
- Node.js 20+
- Express 5
- dotenv
- cookie-parser
- multer
- Helmet
- node:crypto
- PostgreSQL driver `pg`

## Database
- PostgreSQL 16
- SQL schema + migration files
- Tables تشمل المستخدمين الإداريين، الجلسات، السجل التدقيقي، الإعلانات، الشكاوى، المدفوعات، وإعدادات المنصة.

## Security primitives
- scrypt password hashing
- TOTP 2FA
- AES-256-GCM encryption at rest for TOTP secrets
- HMAC-SHA256 state signing
- SHA-256 token hashing
- HttpOnly/SameSite/Secure cookies
- CSRF token validation
- Helmet security headers
- Rate limiting
- Upload size/type controls

## Payments
- Qi API integration in Backend
- RSA-SHA256 request signing
- Optional response-signature verification
- Payment states: SUCCESS / PENDING / FAIL
- Provider registry for future gateways

## DevOps
- Docker Compose for PostgreSQL
- GitHub Actions
- npm scripts
- CI syntax checks
- Optional frontend/backend deploy hooks
- Git tags for rollback points

## Important
النسخة الحالية لا تحتوي على مكتبات frontend ثقيلة مثل React أو Vue. الواجهة مبنية مباشرة بـ HTML/CSS/JavaScript، وهذا يسهل نقلها إلى استضافة static في المرحلة الحالية.
