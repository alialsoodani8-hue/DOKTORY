# SOUQI — التشغيل المحلي

## المتطلبات

- Node.js 20 أو أحدث.
- npm.
- PostgreSQL 16 أو Docker.
- متصفح حديث.

## PostgreSQL عبر Docker

```bash
docker compose -f docker-compose.postgres.yml up -d
```

## إعداد Backend

```bash
cd backend
npm install
cp .env.example .env
```

ولـ Windows PowerShell يمكن نسخ الملف يدوياً إلى `.env`.

### مفاتيح مطلوبة

- `DATABASE_URL`
- `SESSION_SECRET`
- `ENCRYPTION_KEY`

بوابة Qi تحتاج أيضاً إلى بيانات التاجر الرسمية.

## قاعدة البيانات

طبّق:

```bash
psql "$DATABASE_URL" -f schema.sql
```

ثم المهاجرات المطلوبة بالترتيب.

## فحص الكود

```bash
npm run check
```

## إنشاء Owner تجريبي

```bash
npm run setup:admin
```

سيولد البرنامج بيانات Owner مرة واحدة. احفظ كلمة المرور وTOTP secret في مكان آمن ولا تضعهما في GitHub.

## تشغيل

```bash
npm start
```

## ملاحظة

الإعدادات المحلية ليست إعدادات إنتاج. في الإنتاج استخدم HTTPS، Secret Manager، قاعدة بيانات مُدارة، WAF/CDN، نسخاً احتياطية ومراقبة.
