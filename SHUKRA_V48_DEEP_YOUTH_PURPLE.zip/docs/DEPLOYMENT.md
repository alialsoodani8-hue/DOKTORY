# SOUQI — النشر

## Frontend

الواجهة يمكن نشرها على استضافة static تدعم HTTPS.

## Backend

يحتاج Backend إلى:

- Node.js 20+
- متغيرات البيئة
- اتصال PostgreSQL
- HTTPS أمام الخدمة
- مراقبة وسجلات

## Database

PostgreSQL 16 أو خدمة PostgreSQL مُدارة. لا تفتح منفذ قاعدة البيانات للعامة.

## CI/CD

GitHub Actions يفحص المشروع قبل Deploy. يمكن إضافة Deploy Hooks الخاصة بمزود الاستضافة كـ GitHub Secrets.

## Production checklist

- [ ] Domain وDNS
- [ ] HTTPS
- [ ] PostgreSQL managed + backups
- [ ] Secrets
- [ ] Qi merchant credentials
- [ ] FRONTEND_URL / PUBLIC_BASE_URL
- [ ] COOKIE_SECURE=true
- [ ] TRUST_PROXY مضبوط حسب البنية
- [ ] WAF/CDN
- [ ] Monitoring
- [ ] Restore test للنسخ الاحتياطية
