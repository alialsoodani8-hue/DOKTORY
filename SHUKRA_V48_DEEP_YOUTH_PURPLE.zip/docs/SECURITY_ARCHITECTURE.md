# SOUQI — البنية الأمنية

## طبقات التطبيق

- Helmet security headers.
- HttpOnly + SameSite + Secure cookies في الإنتاج.
- Server-side sessions.
- CSRF validation.
- RBAC للمالك والموظفين.
- TOTP 2FA.
- Rate limiting لمحاولات الدخول والطلبات.
- Audit logs.
- scrypt لكلمات المرور.
- AES-256-GCM لتشفير أسرار TOTP المخزنة.
- SHA-256 لتجزئة رموز الجلسات.
- تحقق توقيع Qi.
- حدود لحجم ونوع الملفات المرفوعة.

## طبقة البنية التحتية المطلوبة للإنتاج

- HTTPS/TLS.
- WAF/CDN.
- Firewall/Security Groups.
- PostgreSQL غير مكشوف مباشرة للإنترنت.
- Backups مشفرة ومختبرة الاسترجاع.
- Secret Manager.
- Monitoring وAlerting.
- تحديثات Node.js وnpm وحزم النظام.

## تنبيه

الحماية 100% غير ممكنة. الهدف هو تقليل سطح الهجوم، كشف النشاط المشبوه، منع الوصول غير المصرح، وتقليل أثر أي حادث.
