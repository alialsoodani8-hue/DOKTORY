SOUQI MARKET | GLOBAL PREMIUM — READY FOR HOSTING

المشروع الآن مجهز ليكون نقطة انطلاق للربط مع الاستضافة مع نظام تحديث شبه تلقائي:

1) الواجهة الرئيسية: index.html
2) بوابة الإدارة: admin/index.html
3) Backend: backend/src/server.js
4) قاعدة البيانات: backend/schema.sql (PostgreSQL)
5) نظام CI/CD: .github/workflows/ci-cd.yml
6) نظام التحديث والنسخ الاحتياطي: ops/UPDATE_SYSTEM.md
7) قائمة الربط بالاستضافة: ops/HOSTING_CHECKLIST_AR.md
8) بنية التشغيل: ops/ARCHITECTURE.md

نظام التحديث:
- كل Push إلى main يمر أولاً بالاختبارات.
- عند النجاح ينشئ GitHub Tag احتياطياً قبل النشر.
- يتم حفظ Artifact للإصدار.
- يمكن تشغيل Deploy Hooks للواجهة والBackend عبر GitHub Secrets.
- عند الفشل لا يتم تنفيذ مرحلة النشر.
- يمكن الرجوع إلى Tag احتياطي وإعادة النشر.

الاستضافة:
- Frontend: Cloudflare Pages أو استضافة Static مماثلة.
- Backend: Node.js 20+ على خدمة تدعم Node.js.
- Database: PostgreSQL مُدار.
- GitHub هو المصدر الرئيسي للكود والإصدارات.

متغيرات Backend الأساسية:
PORT=8080
DATABASE_URL=...
JWT_SECRET=...
FRONTEND_URL=...
COOKIE_SECURE=true

الأمان:
- لا تضع ملف .env الحقيقي داخل GitHub.
- لا تضع مفاتيح Qi أو مفاتيح الدفع في frontend.
- مفاتيح الإنتاج توضع في Secrets الخاصة بالاستضافة.
- RBAC/JWT/bcrypt/Helmet/CORS/Audit Log موجودة في Backend.

ملاحظة مهمة:
النشر التلقائي الفعلي يحتاج ربط المشروع بمزود الاستضافة المختار. هذا الملف يجهز المشروع لذلك، لكنه لا يخترع حساب استضافة أو مفاتيح غير موجودة.

ADMIN / SECURITY UPDATE
- Real Node.js admin authentication scaffold with OWNER + employee roles.
- Passwords use scrypt hashing.
- TOTP 2FA secrets are encrypted at rest with AES-256-GCM.
- Sessions use HttpOnly cookies and server-side session records.
- CSRF token required for state-changing authenticated requests.
- Audit log records admin events.
- Run `npm install`, PostgreSQL schema, then `npm run setup:admin` and `npm start`.

V8 HARDENING:
- Added production readiness endpoint `/api/ready` and database-aware health check.
- Added per-IP/per-identifier authentication rate limiting.
- Bound the 2FA pending cookie to the authenticated user and 5-minute window.
- Added safe CSRF length handling to prevent timingSafeEqual exceptions.
- Added automatic cleanup of expired/revoked admin sessions.
- Added employee enable/disable controls and audit log viewer in Admin UI.
- Added `npm run check` syntax validation used by CI.

V35: Added luxury public payment-card showcase; Qi remains the only currently public live payment route. Other methods are clearly marked as planned/not-live.

V38: Compact real payment-card strip. English labels: Visa Card / Mastercard. Official provider visuals used where available; FastPay shown as a wallet provider, not a card. Qi remains the current public gateway.


V44: تمت إزالة صور بطاقات المصرف من الواجهة العامة مع الإبقاء على بنية الدفع الآمن في Backend.

لغات وتقنيات المشروع: HTML5 + CSS3 + JavaScript (Frontend)، Node.js + Express (Backend)، PostgreSQL (Database)، Service Worker + Web Manifest (PWA).
