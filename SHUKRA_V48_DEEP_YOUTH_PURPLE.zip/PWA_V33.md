# SOUQI MARKET V33 — Index + PWA
- `index.html` هو نقطة البداية الرسمية.
- تمت إضافة `manifest.webmanifest` للتثبيت كتطبيق.
- تمت إضافة `sw.js` للتخزين المؤقت وتجربة PWA.
- تمت إضافة أيقونات SOUQI MARKET 192 و512.
- يظهر زر تثبيت التطبيق عندما يدعم المتصفح تثبيت PWA.
- يجب نشر الموقع عبر HTTPS (أو localhost أثناء التطوير) حتى يعمل Service Worker بشكل صحيح.
- بيانات الـBackend وPostgreSQL تبقى على الخادم ولا تصبح داخل الـPWA.
