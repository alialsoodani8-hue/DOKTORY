# V29 — Owner-only Admin Access

- Public floating ADMIN button removed.
- Control Center entry is placed inside the platform footer.
- The control gate offers two scopes:
  - OWNER: only the platform OWNER account can enter the high-level administration area.
  - EMPLOYEE: only non-OWNER employee accounts can enter employee functions.
- Backend enforces the scope during password login and again during 2FA verification.
- Frontend hiding is not the security boundary; the server-side role check is.
