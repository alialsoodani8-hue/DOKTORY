CREATE TABLE IF NOT EXISTS marketplace_listing_engagements (
 id BIGSERIAL PRIMARY KEY,
 listing_id UUID REFERENCES marketplace_listings(id) ON DELETE CASCADE,
 listing_key TEXT NOT NULL,
 event_type TEXT NOT NULL CHECK(event_type IN('VIEW','LIKE','SHARE','FOLLOW')),
 visitor_key TEXT NOT NULL,
 seller_key TEXT,
 event_day DATE NOT NULL DEFAULT CURRENT_DATE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE marketplace_listing_engagements DROP CONSTRAINT IF EXISTS marketplace_listing_engagements_event_type_check;
ALTER TABLE marketplace_listing_engagements ADD CONSTRAINT marketplace_listing_engagements_event_type_check CHECK(event_type IN('VIEW','LIKE','SHARE','FOLLOW'));
ALTER TABLE marketplace_listing_engagements ADD COLUMN IF NOT EXISTS seller_key TEXT;
ALTER TABLE marketplace_listing_engagements ADD COLUMN IF NOT EXISTS event_day DATE NOT NULL DEFAULT CURRENT_DATE;
CREATE UNIQUE INDEX IF NOT EXISTS ux_engagement_like ON marketplace_listing_engagements(listing_key,visitor_key,event_type) WHERE event_type='LIKE';
CREATE UNIQUE INDEX IF NOT EXISTS ux_engagement_follow ON marketplace_listing_engagements(seller_key,visitor_key,event_type) WHERE event_type='FOLLOW';
CREATE UNIQUE INDEX IF NOT EXISTS ux_engagement_view_day ON marketplace_listing_engagements(listing_key,visitor_key,event_type,event_day) WHERE event_type='VIEW';
CREATE INDEX IF NOT EXISTS idx_engagement_listing ON marketplace_listing_engagements(listing_key,event_type,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_engagement_seller ON marketplace_listing_engagements(seller_key,event_type,created_at DESC);
