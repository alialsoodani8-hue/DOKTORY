CREATE TABLE IF NOT EXISTS payment_gateways (
  code text PRIMARY KEY,
  display_name text NOT NULL,
  active boolean NOT NULL DEFAULT false,
  countries text[] NOT NULL DEFAULT '{}',
  currencies text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO payment_gateways(code,display_name,active,countries,currencies) VALUES
('QI','Qi','true','{IQ}','{IQD}'),
('ZAINCASH','ZainCash','false','{IQ}','{IQD}'),
('FIB','FIB','false','{IQ}','{IQD}'),
('FASTPAY','FastPay','false','{IQ}','{IQD}'),
('VISA','Visa / Mastercard Gateway','false','{}','{USD,EUR,GBP,SAR,AED,TRY,IQD}')
ON CONFLICT (code) DO NOTHING;
