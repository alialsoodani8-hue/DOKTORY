ALTER TABLE marketplace_listings ADD COLUMN IF NOT EXISTS seller_name text;
ALTER TABLE marketplace_listings ADD COLUMN IF NOT EXISTS seller_phone text;
ALTER TABLE marketplace_listings ADD COLUMN IF NOT EXISTS seller_email text;
ALTER TABLE marketplace_listings ADD COLUMN IF NOT EXISTS file_name text;
