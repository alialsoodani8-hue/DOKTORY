CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('OWNER','ADMIN','FINANCE','OPERATIONS','SUPPORT')),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  totp_secret_enc TEXT,
  recovery_codes_hashes JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_login_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS admin_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  csrf_token TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_admin_sessions_token ON admin_sessions(token_hash);

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  actor_user_id UUID REFERENCES admin_users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target TEXT,
  ip INET,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);

CREATE TABLE IF NOT EXISTS marketplace_listings (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), title text NOT NULL, category text NOT NULL, seller_user_id uuid REFERENCES admin_users(id), seller_name text, seller_phone text, seller_email text, file_name text, price numeric(18,2), price_currency text NOT NULL DEFAULT 'IQD', image_data jsonb NOT NULL DEFAULT '[]'::jsonb, status text NOT NULL DEFAULT 'PENDING', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS marketplace_complaints (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), listing_id uuid REFERENCES marketplace_listings(id) ON DELETE SET NULL, reporter text, subject text NOT NULL, status text NOT NULL DEFAULT 'OPEN', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS marketplace_payments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), listing_id uuid REFERENCES marketplace_listings(id) ON DELETE SET NULL, seller_user_id uuid REFERENCES admin_users(id) ON DELETE SET NULL, provider text NOT NULL, amount numeric(18,2) NOT NULL DEFAULT 0, currency text NOT NULL DEFAULT 'IQD', status text NOT NULL DEFAULT 'PENDING', payment_request_id text, payment_id text, metadata jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS platform_settings (
 key text PRIMARY KEY,
 value jsonb NOT NULL,
 updated_by uuid REFERENCES admin_users(id) ON DELETE SET NULL,
 updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS marketplace_listing_engagements (
 id BIGSERIAL PRIMARY KEY, listing_id uuid REFERENCES marketplace_listings(id) ON DELETE CASCADE,
 listing_key text NOT NULL, event_type text NOT NULL CHECK(event_type IN('VIEW','LIKE','SHARE','FOLLOW')),
 visitor_key text NOT NULL, seller_key text, event_day date NOT NULL DEFAULT CURRENT_DATE, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_engagement_like ON marketplace_listing_engagements(listing_key,visitor_key,event_type) WHERE event_type='LIKE';
CREATE UNIQUE INDEX IF NOT EXISTS ux_engagement_follow ON marketplace_listing_engagements(seller_key,visitor_key,event_type) WHERE event_type='FOLLOW';
CREATE UNIQUE INDEX IF NOT EXISTS ux_engagement_view_day ON marketplace_listing_engagements(listing_key,visitor_key,event_type,event_day) WHERE event_type='VIEW';
