ALTER TABLE marketplace_listings ADD COLUMN IF NOT EXISTS price numeric(18,2);
ALTER TABLE marketplace_listings ADD COLUMN IF NOT EXISTS price_currency text NOT NULL DEFAULT 'IQD';
ALTER TABLE marketplace_listings ADD COLUMN IF NOT EXISTS image_data jsonb NOT NULL DEFAULT '[]'::jsonb;
CREATE INDEX IF NOT EXISTS idx_marketplace_listings_updated_at ON marketplace_listings(updated_at DESC);
