# Global Payments

Central backend model: order -> payment intent -> provider -> verified status -> commission -> seller balance -> payout -> settlement.

Provider is selected by market/country and currency. Iraq can use Qi; Saudi Arabia, UAE and other markets use locally appropriate licensed providers.

Statuses: PENDING, PROCESSING, SUCCESS, FAILED, REFUNDED, PARTIALLY_REFUNDED, PAYOUT_PENDING, PAID_OUT.

Do not activate a paid listing until server-side verification succeeds.

## Multi-gateway architecture (V27)
SOUQI MARKET now has a provider registry for Qi, ZainCash, FIB, FastPay, and Visa/Mastercard gateway. Gateway availability is country/currency aware and can be enabled/disabled by OWNER in the Admin API. Provider secrets must remain in Backend environment/secret management. Only Qi has a real API adapter in this release; other providers are intentionally marked as configured/ready-for-credentials and must not be represented as live until their official merchant APIs, contracts, credentials, webhook rules, and settlement details are supplied.
