ALTER TABLE marketplace_payments ADD COLUMN IF NOT EXISTS payment_request_id text;
ALTER TABLE marketplace_payments ADD COLUMN IF NOT EXISTS payment_id text;
ALTER TABLE marketplace_payments ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}'::jsonb;
CREATE UNIQUE INDEX IF NOT EXISTS marketplace_payments_payment_request_id_uq ON marketplace_payments(payment_request_id) WHERE payment_request_id IS NOT NULL;
