import process from 'node:process';
const base=process.env.TQ_URL||'http://localhost:8080';
const r=await fetch(`${base}/api/health`); if(!r.ok) throw new Error(`Health failed: ${r.status}`); console.log('OK:',await r.json());
