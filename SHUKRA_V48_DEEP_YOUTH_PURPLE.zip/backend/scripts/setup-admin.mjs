import 'dotenv/config';
import crypto from 'node:crypto';
import {Pool} from 'pg';
import {hashPassword,generateTotpSecret,encryptText} from '../src/security.js';

for(const k of ['DATABASE_URL','ENCRYPTION_KEY']) if(!process.env[k]) throw new Error(`Missing ${k}`);
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.NODE_ENV==='production'?{rejectUnauthorized:false}:false});
const username=`owner_${crypto.randomBytes(4).toString('hex')}`;
const email=`owner-${crypto.randomBytes(4).toString('hex')}@tq.local`;
const password=crypto.randomBytes(18).toString('base64url');
const secret=generateTotpSecret();
const hash=await hashPassword(password); const enc=encryptText(secret,process.env.ENCRYPTION_KEY);
await pool.query('INSERT INTO admin_users(username,email,password_hash,role,totp_secret_enc) VALUES($1,$2,$3,\'OWNER\',$4)',[username,email,hash,enc]);
console.log('\nTQ MARKET OWNER CREATED\n'); console.log({username,email,password,totpSecret:secret}); console.log('\nStore these credentials securely. The password is shown once.\n'); await pool.end();
