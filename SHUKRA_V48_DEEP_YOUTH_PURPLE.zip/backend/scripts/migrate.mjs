import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import {Pool} from 'pg';

if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required');
const pool = new Pool({connectionString:process.env.DATABASE_URL, ssl:process.env.NODE_ENV==='production'?{rejectUnauthorized:false}:false});
const files=['schema.sql','migrate_v12.sql','migrate_v26_qi.sql','migrate_v27_payment_gateways.sql','migrate_v30_platform_settings.sql','migrate_v31_content_control.sql'];
try {
  for (const file of files) {
    const sql=await fs.readFile(path.join(process.cwd(),file),'utf8');
    if (sql.trim()) { console.log(`Applying ${file}...`); await pool.query(sql); }
  }
  console.log('PostgreSQL database is ready.');
} finally { await pool.end(); }
