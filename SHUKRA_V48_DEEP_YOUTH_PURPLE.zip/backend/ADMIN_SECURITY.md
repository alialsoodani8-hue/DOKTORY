# SOUQI MARKET Admin Security

This package now includes a real admin authentication flow scaffold:

1. `npm install`
2. Create PostgreSQL database and run `psql "$DATABASE_URL" -f schema.sql`.
3. Copy `.env.example` to `.env` and set strong secrets.
4. Generate a 32-byte base64 encryption key with `openssl rand -base64 32`.
5. Run `npm run setup:admin` once. Credentials are printed once; store them securely.
6. Run `npm start`.
7. Open `/admin` or the site's ADMIN button.
8. Login with username/email + password, then TOTP 2FA.

Roles: OWNER, ADMIN, FINANCE, OPERATIONS, SUPPORT.

Owner-only actions: create/disable employees and manage privileged administration.
Employees cannot grant themselves permissions. Qi secrets must remain server-side in a secret manager/environment, never in frontend code.

Before public production launch, place the app behind HTTPS, use a managed PostgreSQL service, secret manager, WAF/rate limiting, monitoring, backups, and tested recovery procedures.
