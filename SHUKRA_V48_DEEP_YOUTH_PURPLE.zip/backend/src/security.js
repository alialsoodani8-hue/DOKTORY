import crypto from 'node:crypto';

const b64url = (b) => b.toString('base64').replaceAll('+','-').replaceAll('/','_').replaceAll('=','');
const fromB64url = (s) => Buffer.from(s.replaceAll('-','+').replaceAll('_','/'), 'base64');

export function randomToken(bytes=32){ return b64url(crypto.randomBytes(bytes)); }
export function sha256(value){ return crypto.createHash('sha256').update(value).digest('hex'); }

export async function hashPassword(password){
  const salt = crypto.randomBytes(16);
  const derived = await new Promise((resolve,reject)=>crypto.scrypt(password,salt,64,{N:16384,r:8,p:1},(e,d)=>e?reject(e):resolve(d)));
  return `scrypt$16384$8$1$${salt.toString('base64')}$${derived.toString('base64')}`;
}

export async function verifyPassword(password, encoded){
  try{
    const [,N,r,p,salt64,hash64] = encoded.split('$');
    const salt=Buffer.from(salt64,'base64'); const expected=Buffer.from(hash64,'base64');
    const actual=await new Promise((resolve,reject)=>crypto.scrypt(password,salt,expected.length,{N:Number(N),r:Number(r),p:Number(p)},(e,d)=>e?reject(e):resolve(d)));
    return crypto.timingSafeEqual(actual,expected);
  }catch{return false;}
}

function base32Decode(input){
  const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits=0,value=0,out=[];
  for(const ch of input.replace(/=+$/,'').toUpperCase().replace(/\s/g,'')){
    const idx=alphabet.indexOf(ch); if(idx<0) throw new Error('Invalid base32');
    value=(value<<5)|idx; bits+=5;
    if(bits>=8){bits-=8; out.push((value>>bits)&255);}
  }
  return Buffer.from(out);
}

export function generateTotpSecret(){ return base64ToBase32(crypto.randomBytes(20)); }
function base64ToBase32(buf){
  const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits=0,value=0,out='';
  for(const byte of buf){ value=(value<<8)|byte; bits+=8; while(bits>=5){bits-=5;out+=alphabet[(value>>bits)&31];} }
  if(bits>0) out+=alphabet[(value<<(5-bits))&31]; return out;
}

export function totpCode(secret, counter=Math.floor(Date.now()/30000)){
  const key=base32Decode(secret); const msg=Buffer.alloc(8); msg.writeBigUInt64BE(BigInt(counter));
  const h=crypto.createHmac('sha1',key).update(msg).digest(); const offset=h[19]&15;
  const bin=((h[offset]&127)<<24)|(h[offset+1]<<16)|(h[offset+2]<<8)|h[offset+3];
  return String(bin%1000000).padStart(6,'0');
}
export function verifyTotp(secret, code){
  if(!/^\d{6}$/.test(String(code||''))) return false;
  const c=Math.floor(Date.now()/30000); return [c-1,c,c+1].some(x=>crypto.timingSafeEqual(Buffer.from(totpCode(secret,x)),Buffer.from(String(code))));
}

export function encryptText(plaintext,keyString){
  const key=Buffer.from(keyString,'base64'); if(key.length!==32) throw new Error('ENCRYPTION_KEY must decode to 32 bytes');
  const iv=crypto.randomBytes(12); const cipher=crypto.createCipheriv('aes-256-gcm',key,iv); const ct=Buffer.concat([cipher.update(plaintext,'utf8'),cipher.final()]);
  return `${b64url(iv)}.${b64url(cipher.getAuthTag())}.${b64url(ct)}`;
}
export function decryptText(payload,keyString){
  const key=Buffer.from(keyString,'base64'); const [ivS,tagS,ctS]=payload.split('.');
  const decipher=crypto.createDecipheriv('aes-256-gcm',key,fromB64url(ivS)); decipher.setAuthTag(fromB64url(tagS));
  return Buffer.concat([decipher.update(fromB64url(ctS)),decipher.final()]).toString('utf8');
}
