import 'dotenv/config';
import express from 'express';
import multer from 'multer';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import crypto from 'node:crypto';
import fs from 'node:fs';
import {Pool} from 'pg';
import {hashPassword,verifyPassword,sha256,randomToken,generateTotpSecret,verifyTotp,encryptText,decryptText} from './security.js';

const app=express();
const contentUpload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024}});
const port=Number(process.env.PORT||8080);
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.NODE_ENV==='production'?{rejectUnauthorized:false}:false,max:Number(process.env.DB_POOL_MAX||10),idleTimeoutMillis:30000,connectionTimeoutMillis:10000});
pool.on('error',err=>console.error('PostgreSQL pool error:',err.message));
app.set('trust proxy', Number(process.env.TRUST_PROXY||0));
app.use(helmet({crossOriginResourcePolicy:{policy:'cross-origin'}}));
app.use(express.json({limit:'1mb'})); app.use(cookieParser());
app.use((req,res,next)=>{res.setHeader('Cache-Control','no-store'); next();});
app.use((req,res,next)=>{if(!req.cookies.souqi_visitor_key){res.cookie('souqi_visitor_key',crypto.randomBytes(18).toString('hex'),{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:31536000000,path:'/'});}next();});
app.get('/api/health',async(req,res)=>{try{await pool.query('SELECT 1');res.json({ok:true,database:true});}catch(e){res.status(503).json({ok:false,database:false});}});

const attempts=new Map();
function rateLimit(req,res,next){
  const key=`${req.ip}:${req.path}`; const now=Date.now(); const item=attempts.get(key)||{count:0,at:now};
  if(now-item.at>15*60*1000){item.count=0;item.at=now;} item.count++;
  attempts.set(key,item); if(item.count>60) return res.status(429).json({error:'Too many requests'}); next();
}
function authRateLimit(req,res,next){
  const identifier=String(req.body?.identifier||'').trim().toLowerCase();
  const key=`auth:${req.ip}:${identifier}`; const now=Date.now(); const item=attempts.get(key)||{count:0,at:now};
  if(now-item.at>15*60*1000){item.count=0;item.at=now;} item.count++; attempts.set(key,item);
  if(item.count>10) return res.status(429).json({error:'Too many login attempts. Try again later.'}); next();
}
function requireEnv(){for(const k of ['DATABASE_URL','SESSION_SECRET','ENCRYPTION_KEY']) if(!process.env[k]) throw new Error(`Missing ${k}`);}
function signState(value){return crypto.createHmac('sha256',process.env.SESSION_SECRET).update(value).digest('hex');}

function qiRequired(){for(const k of ['QI_API_BASE_URL','QI_CLIENT_ID','QI_PRIVATE_KEY','QI_KEY_VERSION','QI_PRODUCT_CODE','PUBLIC_BASE_URL']) if(!process.env[k]) throw new Error(`Missing ${k}`)}
function qiPrivateKey(){const raw=process.env.QI_PRIVATE_KEY||''; return raw.includes('\\n')?raw.replace(/\\n/g,'\n'):raw;}
function qiSign(uri,body,requestTime){const content=`POST ${uri}\n${process.env.QI_CLIENT_ID}.${requestTime}.${body}`;const signer=crypto.createSign('RSA-SHA256');signer.update(content);signer.end();return signer.sign(qiPrivateKey()).toString('base64');}
function qiVerifyResponse(uri,body,responseTime,signature){if(!process.env.QI_PUBLIC_KEY||!signature) return false; const m=signature.match(/signature=([^,]+)/); if(!m) return false; const content=`POST ${uri}\n${process.env.QI_CLIENT_ID}.${responseTime}.${body}`;const v=crypto.createVerify('RSA-SHA256');v.update(content);v.end();return v.verify(process.env.QI_PUBLIC_KEY,Buffer.from(decodeURIComponent(m[1]),'base64'));}
async function qiPost(uri,payload){qiRequired();const body=JSON.stringify(payload);const requestTime=new Date().toISOString();const signature=qiSign(uri,body,requestTime);const r=await fetch(`${process.env.QI_API_BASE_URL.replace(/\/$/,'')}${uri}`,{method:'POST',headers:{'Content-Type':'application/json','Client-Id':process.env.QI_CLIENT_ID,'Request-Time':requestTime,'Signature':`algorithm=RSA256, keyVersion=${process.env.QI_KEY_VERSION}, signature=${encodeURIComponent(signature)}`},body});const text=await r.text();let data;try{data=JSON.parse(text)}catch{data={raw:text}};if(!r.ok) throw new Error(`Qi HTTP ${r.status}`);const responseTime=r.headers.get('Response-Time');const responseSig=r.headers.get('Signature');if(process.env.QI_PUBLIC_KEY&&responseTime&&responseSig&&!qiVerifyResponse(uri,text,responseTime,responseSig)) throw new Error('Qi response signature verification failed');return data;}

async function audit(actor,action,target,req,metadata={}){await pool.query('INSERT INTO audit_logs(actor_user_id,action,target,ip,metadata) VALUES($1,$2,$3,$4,$5)',[actor||null,action,target||null,req.ip,metadata]);}

async function auth(req,res,next){
  const raw=req.cookies.souqi_admin_session; if(!raw) return res.status(401).json({error:'Unauthorized'});
  const {rows}=await pool.query(`SELECT s.*,u.username,u.email,u.role,u.active FROM admin_sessions s JOIN admin_users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>now()`,[sha256(raw)]);
  if(!rows[0]||!rows[0].active) return res.status(401).json({error:'Unauthorized'}); req.admin=rows[0]; next();
}
function role(...roles){return (req,res,next)=>roles.includes(req.admin.role)?next():res.status(403).json({error:'Forbidden'});}
function csrf(req,res,next){const h=req.get('x-csrf-token'); const expected=req.admin?.csrf_token||''; if(!h||!expected||h.length!==expected.length) return res.status(403).json({error:'CSRF validation failed'}); if(!crypto.timingSafeEqual(Buffer.from(h),Buffer.from(expected))) return res.status(403).json({error:'CSRF validation failed'}); next();}

app.post('/api/listings',rateLimit,async(req,res)=>{
  const {title,category,sellerName,sellerPhone,sellerEmail,fileName}=req.body||{};
  if(!title||!category||!sellerName||!sellerPhone||!sellerEmail) return res.status(400).json({error:'يرجى إكمال عنوان الإعلان والقسم وبيانات البائع'});
  const {rows}=await pool.query(`INSERT INTO marketplace_listings(title,category,seller_name,seller_phone,seller_email,file_name,status) VALUES($1,$2,$3,$4,$5,$6,'PENDING') RETURNING id,title,category,status,created_at`,[String(title).trim(),String(category).trim(),String(sellerName).trim(),String(sellerPhone).trim(),String(sellerEmail).trim(),fileName?String(fileName).slice(0,255):null]);
  res.status(201).json({ok:true,item:rows[0],message:'تم إرسال الإعلان إلى لوحة الإدارة للمراجعة'});
});



const GATEWAY_ENV={QI:'QI_ENABLED',ZAINCASH:'ZAINCASH_ENABLED',FIB:'FIB_ENABLED',FASTPAY:'FASTPAY_ENABLED',VISA:'CARD_GATEWAY_ENABLED'};
const GATEWAY_NAMES={QI:'Qi',ZAINCASH:'ZainCash',FIB:'FIB',FASTPAY:'FastPay',VISA:'Visa / Mastercard Gateway'};
const GATEWAY_COUNTRIES={QI:['IQ'],ZAINCASH:['IQ'],FIB:['IQ'],FASTPAY:['IQ'],VISA:[]};
const GATEWAY_CURRENCIES={QI:['IQD'],ZAINCASH:['IQD'],FIB:['IQD'],FASTPAY:['IQD'],VISA:['IQD','USD','EUR','GBP','SAR','AED','TRY']};
function gatewayEnabled(code){return String(process.env[GATEWAY_ENV[code]]||'false').toLowerCase()==='true'}
function supportedGateway(code,currency){return Boolean(GATEWAY_ENV[code])&&gatewayEnabled(code)&&GATEWAY_CURRENCIES[code].includes(currency)}
app.get('/api/payments/gateways',rateLimit,async(req,res)=>{
  // Public clients receive ONLY the Qi gateway. Other provider names/configuration
  // are intentionally not exposed through the public API.
  const country=String(req.query.country||'IQ').toUpperCase(),currency=String(req.query.currency||'IQD').toUpperCase();
  const qiAvailable=gatewayEnabled('QI') && (GATEWAY_COUNTRIES.QI.length===0||GATEWAY_COUNTRIES.QI.includes(country)) && GATEWAY_CURRENCIES.QI.includes(currency);
  const ready=qiAvailable && Boolean(process.env.QI_API_BASE_URL&&process.env.QI_CLIENT_ID&&process.env.QI_PRIVATE_KEY&&process.env.QI_KEY_VERSION&&process.env.QI_PRODUCT_CODE&&process.env.PUBLIC_BASE_URL);
  res.json({items:qiAvailable?[{code:'QI',name:'Qi',countries:['IQ'],currencies:['IQD'],ready}]:[]});
});
app.post('/api/payments/create',rateLimit,async(req,res)=>{
  const provider=String(req.body?.provider||'').toUpperCase();
  if(provider==='QI') return res.status(307).json({error:'Use /api/payments/qi/create for Qi'});
  // Never expose internal provider inventory or implementation details to public callers.
  // Only Qi is a public payment route in this release.
  return res.status(404).json({error:'بوابة الدفع غير متاحة'});
});

app.post('/api/payments/qi/create',rateLimit,async(req,res)=>{
  try{
    const {listingId,amount,buyerEmail,buyerId}=req.body||{}; const numeric=Number(amount);
    if(!listingId||!Number.isFinite(numeric)||numeric<=0) return res.status(400).json({error:'رقم الإعلان والمبلغ مطلوبان'});
    const {rows}=await pool.query('SELECT id,title,status FROM marketplace_listings WHERE id=$1',[listingId]); if(!rows[0]) return res.status(404).json({error:'الإعلان غير موجود'});
    const requestId=`BM${Date.now()}${crypto.randomBytes(8).toString('hex')}`.slice(0,64);
    const fils=String(Math.round(numeric*1000));
    const payload={productCode:process.env.QI_PRODUCT_CODE,paymentRequestId:requestId,paymentAmount:{currency:'IQD',value:fils},order:{orderDescription:`SOUQI MARKET - ${String(rows[0].title).slice(0,120)}`,buyer:buyerId?{referenceBuyerId:String(buyerId)}:undefined},paymentExpiryTime:new Date(Date.now()+30*60*1000).toISOString(),paymentRedirectUrl:`${process.env.PUBLIC_BASE_URL.replace(/\/$/,'')}/?qi=return&requestId=${encodeURIComponent(requestId)}`,paymentNotifyUrl:`${process.env.PUBLIC_BASE_URL.replace(/\/$/,'')}/api/payments/qi/notify`};
    if(!payload.order.buyer) delete payload.order.buyer;
    const qi=await qiPost('/v1/payments/pay',payload); const status=qi?.result?.resultStatus==='A'?'PENDING':qi?.result?.resultStatus==='S'?'SUCCESS':'FAIL';
    await pool.query(`INSERT INTO marketplace_payments(listing_id,provider,amount,currency,status,payment_request_id,payment_id,metadata) VALUES($1,'QI',$2,'IQD',$3,$4,$5,$6)`,[listingId,numeric,status,requestId,qi.paymentId||null,JSON.stringify({buyerEmail:buyerEmail||null,qiResult:qi?.result||null})]);
    if(status==='SUCCESS') await pool.query("UPDATE marketplace_listings SET status='PUBLISHED',updated_at=now() WHERE id=$1",[listingId]);
    const redirect=qi?.redirectActionForm?.redirectionUrl||null; if(status==='PENDING'&&!redirect) return res.status(502).json({error:'Qi لم يعطِ رابط الدفع'});
    res.json({ok:true,status,paymentId:qi.paymentId||null,paymentRequestId:requestId,redirectUrl:redirect});
  }catch(e){console.error('QI create',e);res.status(502).json({error:'تعذر الاتصال ببوابة Qi. تأكد من بيانات التاجر في Backend.'});}
});
app.post('/api/payments/qi/notify',express.raw({type:'application/json'}),async(req,res)=>{
  try{const text=Buffer.isBuffer(req.body)?req.body.toString('utf8'):JSON.stringify(req.body||{});const data=JSON.parse(text);const requestId=data.paymentRequestId; if(!requestId){return res.status(400).json({error:'paymentRequestId required'})}
    if(process.env.QI_PUBLIC_KEY){const responseTime=req.get('Response-Time');const sig=req.get('Signature');if(!responseTime||!sig||!qiVerifyResponse('/v1/payments/notifyPayment',text,responseTime,sig)) return res.status(401).json({error:'Invalid Qi signature'});}
    const status=data.paymentStatus==='SUCCESS'?'SUCCESS':data.paymentStatus==='FAIL'?'FAIL':'PENDING'; const {rows}=await pool.query('UPDATE marketplace_payments SET status=$1,payment_id=COALESCE($2,payment_id),metadata=COALESCE(metadata,\'{}\'::jsonb)||$3::jsonb,updated_at=now() WHERE payment_request_id=$4 RETURNING listing_id',[status,data.paymentId||null,JSON.stringify({notification:data}),requestId]);
    if(rows[0]?.listing_id&&status==='SUCCESS') await pool.query("UPDATE marketplace_listings SET status='PUBLISHED',updated_at=now() WHERE id=$1",[rows[0].listing_id]); if(rows[0]?.listing_id&&status==='FAIL') await pool.query("UPDATE marketplace_listings SET status='PENDING',updated_at=now() WHERE id=$1 AND status<>'PUBLISHED'",[rows[0].listing_id]); res.json({ok:true});
  }catch(e){console.error('QI notify',e);res.status(500).json({error:'Notification processing failed'});}
});
app.get('/api/payments/qi/status/:requestId',rateLimit,async(req,res)=>{try{qiRequired();const qi=await qiPost('/v1/payments/inquiryPayment',{paymentRequestId:req.params.requestId});const status=qi?.paymentStatus==='SUCCESS'?'SUCCESS':qi?.paymentStatus==='FAIL'?'FAIL':'PENDING';const {rows}=await pool.query('UPDATE marketplace_payments SET status=$1,payment_id=COALESCE($2,payment_id),updated_at=now() WHERE payment_request_id=$3 RETURNING listing_id',[status,qi.paymentId||null,req.params.requestId]);if(rows[0]?.listing_id&&status==='SUCCESS')await pool.query("UPDATE marketplace_listings SET status='PUBLISHED',updated_at=now() WHERE id=$1",[rows[0].listing_id]);res.json({ok:true,status,paymentId:qi.paymentId||null});}catch(e){console.error('QI status',e);res.status(502).json({error:'تعذر الاستعلام من Qi'});}});

app.get('/api/health',async(req,res)=>{try{await pool.query('SELECT 1');res.json({ok:true,service:'SOUQI MARKET backend',database:true});}catch{res.status(503).json({ok:false,service:'SOUQI MARKET backend',database:false});}});
app.get('/api/ready',async(req,res)=>{try{await pool.query('SELECT 1');res.json({ready:true});}catch{res.status(503).json({ready:false});}});
setInterval(()=>{pool.query("DELETE FROM admin_sessions WHERE expires_at < now() OR revoked_at IS NOT NULL").catch(()=>{});},60*60*1000).unref();
app.post('/api/admin/login',authRateLimit,async(req,res)=>{
  const {identifier,password,scope='EMPLOYEE'}=req.body||{}; if(!identifier||!password) return res.status(400).json({error:'Identifier and password are required'}); if(!['OWNER','EMPLOYEE'].includes(scope)) return res.status(400).json({error:'Invalid login scope'});
  const {rows}=await pool.query('SELECT * FROM admin_users WHERE lower(username)=lower($1) OR lower(email)=lower($1) LIMIT 1',[identifier]); const u=rows[0];
  if(!u||!u.active||!(await verifyPassword(password,u.password_hash))) return res.status(401).json({error:'Invalid credentials'}); if((scope==='OWNER' && u.role!=='OWNER') || (scope==='EMPLOYEE' && u.role==='OWNER')) return res.status(403).json({error:scope==='OWNER'?'دخول الإدارة العليا مخصص لمالك المنصة فقط':'استخدم بوابة دخول المالك لهذا الحساب'});
  const pendingPayload=`${u.id}:${Date.now()}:${scope}:${randomToken(16)}`; const pending=signState(pendingPayload)+'.'+Buffer.from(pendingPayload).toString('base64url'); res.cookie('souqi_admin_pending',pending,{httpOnly:true,sameSite:'lax',secure:process.env.COOKIE_SECURE==='true',maxAge:5*60*1000});
  await audit(u.id,'LOGIN_PASSWORD_OK','admin',req); res.json({ok:true,requires2fa:true});
});
app.post('/api/admin/verify-2fa',authRateLimit,async(req,res)=>{
  const pending=req.cookies.souqi_admin_pending; const {identifier,code}=req.body||{}; if(!pending||!identifier||!code) return res.status(400).json({error:'2FA verification required'});
  const [sig,payload64]=String(pending).split('.'); let pendingPayload=''; try{pendingPayload=Buffer.from(payload64||'','base64url').toString('utf8');}catch{} if(!sig||!payload64||signState(pendingPayload)!==sig||Date.now()-Number(pendingPayload.split(':')[1]||0)>5*60*1000) return res.status(401).json({error:'2FA session expired'}); const pendingParts=pendingPayload.split(':'); const pendingUserId=pendingParts[0]; const pendingScope=pendingParts[2]||'EMPLOYEE'; if(!['OWNER','EMPLOYEE'].includes(pendingScope)||pendingScope!==String(req.body?.scope||'')) return res.status(403).json({error:'Invalid login scope'}); const {rows}=await pool.query('SELECT * FROM admin_users WHERE id=$1 AND (lower(username)=lower($2) OR lower(email)=lower($2)) LIMIT 1',[pendingUserId,identifier]); const u=rows[0]; if(!u||!u.active||!u.totp_secret_enc) return res.status(401).json({error:'Invalid 2FA'});
  let secret; try{secret=decryptText(u.totp_secret_enc,process.env.ENCRYPTION_KEY);}catch{return res.status(500).json({error:'2FA configuration error'});}
  if(!verifyTotp(secret,code)) return res.status(401).json({error:'Invalid 2FA code'});
  const raw=randomToken(48), csrf=randomToken(24); await pool.query('INSERT INTO admin_sessions(user_id,token_hash,csrf_token,expires_at) VALUES($1,$2,$3,now()+interval \'8 hours\')',[u.id,sha256(raw),csrf]);
  await pool.query('UPDATE admin_users SET last_login_at=now(),updated_at=now() WHERE id=$1',[u.id]); await audit(u.id,'LOGIN_SUCCESS','admin',req);
  res.clearCookie('souqi_admin_pending'); res.cookie('souqi_admin_session',raw,{httpOnly:true,sameSite:'lax',secure:process.env.COOKIE_SECURE==='true',maxAge:8*60*60*1000}); res.json({ok:true,csrfToken:csrf,user:{username:u.username,email:u.email,role:u.role}});
});
app.post('/api/admin/logout',auth,csrf,async(req,res)=>{await pool.query('UPDATE admin_sessions SET revoked_at=now() WHERE id=$1',[req.admin.id]);await audit(req.admin.user_id,'LOGOUT','admin',req);res.clearCookie('souqi_admin_session');res.json({ok:true});});
app.get('/api/admin/me',auth,(req,res)=>res.json({user:{id:req.admin.user_id,username:req.admin.username,email:req.admin.email,role:req.admin.role},csrfToken:req.admin.csrf_token}));
app.get('/api/admin/employee-access',auth,(req,res)=>res.json({connected:true,platform:'SOUQI MARKET',employee:{id:req.admin.user_id,username:req.admin.username,role:req.admin.role,active:req.admin.active}}));
app.get('/api/admin/overview',auth,async(req,res)=>{const [{rows:a},{rows:s},{rows:l}]=await Promise.all([pool.query('SELECT count(*)::int AS n FROM admin_users'),pool.query('SELECT count(*)::int AS n FROM admin_sessions WHERE revoked_at IS NULL AND expires_at>now()'),pool.query('SELECT count(*)::int AS n FROM audit_logs')]);res.json({users:a[0].n,activeSessions:s[0].n,auditEvents:l[0].n});});
app.get('/api/admin/employees',auth,role('OWNER','ADMIN'),async(req,res)=>{const {rows}=await pool.query("SELECT id,username,email,role,active,created_at,last_login_at FROM admin_users ORDER BY created_at DESC");res.json({employees:rows});});
app.post('/api/admin/employees',auth,role('OWNER'),csrf,async(req,res)=>{
  const {username,email,password,role:newRole}=req.body||{}; if(!username||!email||!password||!['ADMIN','FINANCE','OPERATIONS','SUPPORT'].includes(newRole)) return res.status(400).json({error:'Invalid employee data'});
  const secret=generateTotpSecret(); const rec=[...Array(8)].map(()=>randomToken(5).toUpperCase()); const hashes=await Promise.all(rec.map(x=>hashPassword(x))); const passHash=await hashPassword(password); const enc=encryptText(secret,process.env.ENCRYPTION_KEY);
  try{const {rows}=await pool.query('INSERT INTO admin_users(username,email,password_hash,role,totp_secret_enc,recovery_codes_hashes) VALUES($1,$2,$3,$4,$5,$6) RETURNING id,username,email,role,active',[username,email,passHash,newRole,enc,JSON.stringify(hashes)]);await audit(req.admin.user_id,'EMPLOYEE_CREATED',rows[0].id,req,{role:newRole});res.status(201).json({employee:rows[0],totpSecret:secret,recoveryCodes:rec});}catch(e){res.status(409).json({error:'Username or email already exists'});}
});
app.patch('/api/admin/employees/:id/status',auth,role('OWNER'),csrf,async(req,res)=>{const active=Boolean(req.body?.active);const {rows}=await pool.query('UPDATE admin_users SET active=$1,updated_at=now() WHERE id=$2 AND role<>\'OWNER\' RETURNING id,username,email,role,active',[active,req.params.id]);if(!rows[0])return res.status(404).json({error:'Employee not found'});await pool.query('UPDATE admin_sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL',[req.params.id]);await audit(req.admin.user_id,active?'EMPLOYEE_ENABLED':'EMPLOYEE_DISABLED',req.params.id,req);res.json({employee:rows[0]});});
app.get('/api/admin/audit',auth,role('OWNER','ADMIN'),async(req,res)=>{const {rows}=await pool.query('SELECT a.*,u.username FROM audit_logs a LEFT JOIN admin_users u ON u.id=a.actor_user_id ORDER BY a.created_at DESC LIMIT 200');res.json({events:rows});});
function platformRoles(...roles){return role(...roles)}
app.get('/api/admin/manager-summary',auth,role('OWNER','ADMIN'),async(req,res)=>{
 const q=async(sql)=>{const {rows}=await pool.query(sql);return Number(rows[0]?.n||0)};
 const [users,employees,publishedListings,pendingListings,openComplaints,successPayments,activeSessions,auditEvents]=await Promise.all([
  q('SELECT count(*)::int n FROM admin_users'),
  q("SELECT count(*)::int n FROM admin_users WHERE role <> 'OWNER'"),
  q("SELECT count(*)::int n FROM marketplace_listings WHERE status='PUBLISHED'"),
  q("SELECT count(*)::int n FROM marketplace_listings WHERE status='PENDING'"),
  q("SELECT count(*)::int n FROM marketplace_complaints WHERE status='OPEN'"),
  q("SELECT count(*)::int n FROM marketplace_payments WHERE status='SUCCESS'"),
  q("SELECT count(*)::int n FROM admin_sessions WHERE revoked_at IS NULL AND expires_at>now()"),
  q('SELECT count(*)::int n FROM audit_logs')
 ]);
 const {rows:revenue}=await pool.query("SELECT currency,COALESCE(SUM(amount),0)::numeric total,COUNT(*)::int count FROM marketplace_payments WHERE status='SUCCESS' GROUP BY currency ORDER BY currency");
 const permissions=[
  {role:'OWNER',employees:true,listings:true,complaints:true,payments:true,revenue:true},
  {role:'ADMIN',employees:true,listings:true,complaints:true,payments:true,revenue:false},
  {role:'FINANCE',employees:false,listings:false,complaints:false,payments:true,revenue:true},
  {role:'OPERATIONS',employees:false,listings:true,complaints:true,payments:false,revenue:false},
  {role:'SUPPORT',employees:false,listings:false,complaints:true,payments:false,revenue:false}
 ];
 let database=true; try{await pool.query('SELECT 1')}catch{database=false}
 res.json({counts:{users,employees,publishedListings,pendingListings,openComplaints,successPayments,activeSessions,auditEvents},revenue,permissions,health:{backend:true,database}});
});
app.get('/api/admin/platform-summary',auth,platformRoles('OWNER','ADMIN','OPERATIONS','FINANCE','SUPPORT'),async(req,res)=>{
 const q=async(sql)=>{const {rows}=await pool.query(sql);return Number(rows[0]?.n||0)};
 const [listings,sellers,complaints,payments]=await Promise.all([
  q("SELECT count(*)::int n FROM marketplace_listings"),
  q("SELECT count(*)::int n FROM admin_users WHERE role <> 'OWNER'"),
  q("SELECT count(*)::int n FROM marketplace_complaints WHERE status='OPEN'"),
  q("SELECT count(*)::int n FROM marketplace_payments WHERE status='PENDING'")
 ]); res.json({listings,sellers,openComplaints:complaints,pendingPayments:payments});
});
app.get('/api/admin/listings',auth,platformRoles('OWNER','ADMIN','OPERATIONS'),async(req,res)=>{const {rows}=await pool.query("SELECT id,title,category,seller_name,seller_phone,seller_email,price,price_currency,image_data,status,created_at,updated_at FROM marketplace_listings ORDER BY created_at DESC LIMIT 100");res.json({items:rows});});
app.patch('/api/admin/listings/:id/content',auth,platformRoles('OWNER','ADMIN','OPERATIONS'),csrf,async(req,res)=>{const {title,category,price,priceCurrency}=req.body||{}; const n=Number(price); if(!title||!category||!Number.isFinite(n)||n<0) return res.status(400).json({error:'العنوان والقسم والسعر مطلوبة'}); const cur=String(priceCurrency||'IQD').toUpperCase(); const {rows}=await pool.query('UPDATE marketplace_listings SET title=$1,category=$2,price=$3,price_currency=$4,updated_at=now() WHERE id=$5 RETURNING id,title,category,price,price_currency,status,image_data',[String(title).trim(),String(category).trim(),n,cur,req.params.id]); if(!rows[0]) return res.status(404).json({error:'الإعلان غير موجود'}); await audit(req.admin.user_id,'LISTING_CONTENT_UPDATED',req.params.id,req,{price:n,currency:cur}); res.json({item:rows[0]});});
app.post('/api/admin/listings/:id/images',auth,platformRoles('OWNER','ADMIN','OPERATIONS'),csrf,contentUpload.single('image'),async(req,res)=>{try{if(!req.file) return res.status(400).json({error:'اختر صورة'}); if(!/^image\/(jpeg|png|webp|gif)$/.test(req.file.mimetype)) return res.status(400).json({error:'يسمح بصور JPG/PNG/WEBP/GIF فقط'}); const image={id:crypto.randomUUID(),name:req.file.originalname,mime:req.file.mimetype,data:`data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`}; const {rows}=await pool.query("UPDATE marketplace_listings SET image_data=COALESCE(image_data,'[]'::jsonb)||$1::jsonb,updated_at=now() WHERE id=$2 RETURNING id,image_data",[JSON.stringify([image]),req.params.id]); if(!rows[0]) return res.status(404).json({error:'الإعلان غير موجود'}); await audit(req.admin.user_id,'LISTING_IMAGE_ADDED',req.params.id,req,{name:req.file.originalname}); res.json({item:rows[0]});}catch(e){console.error(e);res.status(400).json({error:'تعذر رفع الصورة'})}});
app.delete('/api/admin/listings/:id/images/:imageId',auth,platformRoles('OWNER','ADMIN','OPERATIONS'),csrf,async(req,res)=>{const {rows}=await pool.query("UPDATE marketplace_listings SET image_data=COALESCE((SELECT jsonb_agg(x) FROM jsonb_array_elements(COALESCE(image_data,'[]'::jsonb)) x WHERE x->>'id'<>$1),'[]'::jsonb),updated_at=now() WHERE id=$2 RETURNING id,image_data",[req.params.imageId,req.params.id]); if(!rows[0]) return res.status(404).json({error:'الإعلان غير موجود'}); await audit(req.admin.user_id,'LISTING_IMAGE_DELETED',req.params.id,req,{imageId:req.params.imageId}); res.json({item:rows[0]});});
app.delete('/api/admin/listings/:id',auth,role('OWNER','ADMIN'),csrf,async(req,res)=>{const {rows}=await pool.query('DELETE FROM marketplace_listings WHERE id=$1 RETURNING id,title',[req.params.id]); if(!rows[0]) return res.status(404).json({error:'الإعلان غير موجود'}); await audit(req.admin.user_id,'LISTING_DELETED',req.params.id,req); res.json({ok:true,item:rows[0]});});
app.patch('/api/admin/listings/:id/status',auth,platformRoles('OWNER','ADMIN','OPERATIONS'),csrf,async(req,res)=>{const allowed=['PENDING','PUBLISHED','REJECTED','SUSPENDED'];const status=String(req.body?.status||'');if(!allowed.includes(status))return res.status(400).json({error:'Invalid listing status'});const {rows}=await pool.query('UPDATE marketplace_listings SET status=$1,updated_at=now() WHERE id=$2 RETURNING id,title,category,status',[status,req.params.id]);if(!rows[0])return res.status(404).json({error:'Listing not found'});await audit(req.admin.user_id,'LISTING_STATUS_CHANGED',req.params.id,req,{status});res.json({item:rows[0]});});
app.get('/api/admin/complaints',auth,platformRoles('OWNER','ADMIN','OPERATIONS','SUPPORT'),async(req,res)=>{const {rows}=await pool.query("SELECT id,listing_id,reporter,subject,status,created_at FROM marketplace_complaints ORDER BY created_at DESC LIMIT 100");res.json({items:rows});});
app.patch('/api/admin/complaints/:id/status',auth,platformRoles('OWNER','ADMIN','OPERATIONS','SUPPORT'),csrf,async(req,res)=>{const allowed=['OPEN','IN_REVIEW','RESOLVED','CLOSED'];const status=String(req.body?.status||'');if(!allowed.includes(status))return res.status(400).json({error:'Invalid complaint status'});const {rows}=await pool.query('UPDATE marketplace_complaints SET status=$1 WHERE id=$2 RETURNING id,status,subject',[status,req.params.id]);if(!rows[0])return res.status(404).json({error:'Complaint not found'});await audit(req.admin.user_id,'COMPLAINT_STATUS_CHANGED',req.params.id,req,{status});res.json({item:rows[0]});});

const DEFAULT_PLATFORM_SETTINGS={
 platform_name:'SOUQI MARKET | سوكي',
 default_country:'IQ',
 default_currency:'IQD',
 default_language:'ar',
 support_email:'support@souqimarket.com',
 support_phone:'+964',
 maintenance_mode:false,
 allow_seller_registration:true,
 auto_publish:false,
 require_seller_verification:true,
 enabled_languages:['ar','en'],
 enabled_currencies:['IQD','USD','EUR','GBP','SAR','AED','TRY'],
 facebook_url:'', instagram_url:'', tiktok_url:''
};
app.get('/api/admin/settings',auth,role('OWNER'),async(req,res)=>{
 const {rows}=await pool.query('SELECT key,value FROM platform_settings ORDER BY key');
 const settings={...DEFAULT_PLATFORM_SETTINGS}; for(const r of rows) settings[r.key]=r.value;
 res.json({settings});
});
app.patch('/api/admin/settings',auth,role('OWNER'),csrf,async(req,res)=>{
 const incoming=req.body?.settings||{}; const allowed=Object.keys(DEFAULT_PLATFORM_SETTINGS); const settings={...DEFAULT_PLATFORM_SETTINGS};
 for(const key of allowed) if(Object.prototype.hasOwnProperty.call(incoming,key)) settings[key]=incoming[key];
 if(typeof settings.default_country!=='string'||typeof settings.default_currency!=='string'||typeof settings.default_language!=='string') return res.status(400).json({error:'إعدادات الدولة/العملة/اللغة غير صحيحة'});
 if(!Array.isArray(settings.enabled_languages)||!Array.isArray(settings.enabled_currencies)) return res.status(400).json({error:'قوائم اللغات والعملات يجب أن تكون قوائم'});
 for(const key of allowed){await pool.query('INSERT INTO platform_settings(key,value,updated_by,updated_at) VALUES($1,$2,$3,now()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_by=EXCLUDED.updated_by,updated_at=now()',[key,JSON.stringify(settings[key]),req.admin.user_id]);}
 await audit(req.admin.user_id,'PLATFORM_SETTINGS_UPDATED','platform',req,{keys:allowed});
 res.json({ok:true,settings});
});
app.get('/api/platform/settings',rateLimit,async(req,res)=>{
 const {rows}=await pool.query('SELECT key,value FROM platform_settings ORDER BY key'); const settings={...DEFAULT_PLATFORM_SETTINGS}; for(const r of rows) settings[r.key]=r.value;
 res.json({settings:{platform_name:settings.platform_name,default_country:settings.default_country,default_currency:settings.default_currency,default_language:settings.default_language,support_email:settings.support_email||'support@souqimarket.com'}});
});

app.get('/api/admin/payment-gateways',auth,role('OWNER','ADMIN'),async(req,res)=>{
  const {rows}=await pool.query('SELECT code,display_name,active,countries,currencies,updated_at FROM payment_gateways ORDER BY code');
  const items=rows.map(x=>({...x,envEnabled:gatewayEnabled(x.code),ready:x.code==='QI'?Boolean(process.env.QI_API_BASE_URL&&process.env.QI_CLIENT_ID&&process.env.QI_PRIVATE_KEY&&process.env.QI_KEY_VERSION&&process.env.QI_PRODUCT_CODE&&process.env.PUBLIC_BASE_URL):gatewayEnabled(x.code)}));
  res.json({items});
});
app.patch('/api/admin/payment-gateways/:code',auth,role('OWNER'),csrf,async(req,res)=>{
  const code=String(req.params.code||'').toUpperCase(); if(!GATEWAY_ENV[code]) return res.status(404).json({error:'Unknown gateway'});
  const active=Boolean(req.body?.active); await pool.query('UPDATE payment_gateways SET active=$1,updated_at=now() WHERE code=$2',[active,code]);
  await audit(req.admin.user_id,active?'PAYMENT_GATEWAY_ENABLED':'PAYMENT_GATEWAY_DISABLED',code,req);
  res.json({ok:true,code,active,envEnabled:gatewayEnabled(code),note:'الاعتماد الفعلي يحتاج بيانات المزود الرسمية في Backend.'});
});
app.get('/api/admin/payments',auth,platformRoles('OWNER','ADMIN','FINANCE'),async(req,res)=>{const {rows}=await pool.query("SELECT id,listing_id,provider,amount,currency,status,created_at,updated_at FROM marketplace_payments ORDER BY created_at DESC LIMIT 100");res.json({items:rows});});
app.get('/api/admin/revenue',auth,platformRoles('OWNER','FINANCE'),async(req,res)=>{const {rows}=await pool.query("SELECT currency,COALESCE(SUM(amount),0)::numeric total,COUNT(*)::int count FROM marketplace_payments WHERE status='SUCCESS' GROUP BY currency ORDER BY currency");res.json({items:rows});});




function engagementKey(v){return String(v||'').trim().slice(0,180).replace(/[^\w\-:.@]/g,'_')}
app.get('/api/engagement/:listingKey',rateLimit,async(req,res)=>{
  try{const key=engagementKey(req.params.listingKey);const visitor=req.cookies.souqi_visitor_key;const {rows}=await pool.query("SELECT event_type,COUNT(*)::int count FROM marketplace_listing_engagements WHERE listing_key=$1 GROUP BY event_type",[key]);const counts={VIEW:0,LIKE:0,SHARE:0,FOLLOW:0};rows.forEach(r=>counts[r.event_type]=r.count);const {rows:mine}=await pool.query("SELECT event_type FROM marketplace_listing_engagements WHERE listing_key=$1 AND visitor_key=$2 AND event_type IN('LIKE','VIEW') ORDER BY event_type",[key,visitor]);res.json({counts,liked:mine.some(x=>x.event_type==='LIKE')});}
  catch(e){console.error('engagement get',e);res.status(500).json({error:'تعذر تحميل التفاعل'});}
});
app.post('/api/engagement/:listingKey',rateLimit,async(req,res)=>{
  const key=engagementKey(req.params.listingKey), action=String(req.body?.action||'').toUpperCase(),visitor=req.cookies.souqi_visitor_key;
  if(!['VIEW','LIKE','SHARE'].includes(action))return res.status(400).json({error:'تفاعل غير صالح'});
  try{
    let active=true;
    if(action==='LIKE'){
      const q=await pool.query("SELECT 1 FROM marketplace_listing_engagements WHERE listing_key=$1 AND visitor_key=$2 AND event_type='LIKE' LIMIT 1",[key,visitor]);
      if(q.rowCount){await pool.query("DELETE FROM marketplace_listing_engagements WHERE listing_key=$1 AND visitor_key=$2 AND event_type='LIKE'",[key,visitor]);active=false}
      else await pool.query("INSERT INTO marketplace_listing_engagements(listing_key,event_type,visitor_key) VALUES($1,'LIKE',$2) ON CONFLICT DO NOTHING",[key,visitor]);
    } else if(action==='VIEW') await pool.query("INSERT INTO marketplace_listing_engagements(listing_key,event_type,visitor_key,event_day) VALUES($1,'VIEW',$2,CURRENT_DATE) ON CONFLICT DO NOTHING",[key,visitor]);
    else await pool.query("INSERT INTO marketplace_listing_engagements(listing_key,event_type,visitor_key) VALUES($1,'SHARE',$2)",[key,visitor]);
    const {rows}=await pool.query("SELECT event_type,COUNT(*)::int count FROM marketplace_listing_engagements WHERE listing_key=$1 GROUP BY event_type",[key]);const counts={VIEW:0,LIKE:0,SHARE:0};rows.forEach(r=>counts[r.event_type]=r.count);res.json({ok:true,action,active,counts});
  }catch(e){console.error('engagement post',e);res.status(500).json({error:'تعذر حفظ التفاعل'});}
});
app.post('/api/sellers/:sellerKey/follow',rateLimit,async(req,res)=>{const seller=engagementKey(req.params.sellerKey),visitor=req.cookies.souqi_visitor_key;try{const q=await pool.query("SELECT 1 FROM marketplace_listing_engagements WHERE seller_key=$1 AND visitor_key=$2 AND event_type='FOLLOW' LIMIT 1",[seller,visitor]);let following;if(q.rowCount){await pool.query("DELETE FROM marketplace_listing_engagements WHERE seller_key=$1 AND visitor_key=$2 AND event_type='FOLLOW'",[seller,visitor]);following=false}else{await pool.query("INSERT INTO marketplace_listing_engagements(listing_key,event_type,visitor_key,seller_key) VALUES($1,'FOLLOW',$2,$3) ON CONFLICT DO NOTHING",[`seller:${seller}`,visitor,seller]);following=true}const {rows}=await pool.query("SELECT COUNT(*)::int count FROM marketplace_listing_engagements WHERE seller_key=$1 AND event_type='FOLLOW'",[seller]);res.json({ok:true,following,followers:rows[0].count});}catch(e){console.error('follow',e);res.status(500).json({error:'تعذر حفظ المتابعة'});}});
app.get('/api/sellers/:sellerKey/follow',rateLimit,async(req,res)=>{try{const seller=engagementKey(req.params.sellerKey),visitor=req.cookies.souqi_visitor_key;const q=await pool.query("SELECT EXISTS(SELECT 1 FROM marketplace_listing_engagements WHERE seller_key=$1 AND visitor_key=$2 AND event_type='FOLLOW') following, (SELECT COUNT(*)::int FROM marketplace_listing_engagements WHERE seller_key=$1 AND event_type='FOLLOW') followers",[seller,visitor]);res.json(q.rows[0]);}catch(e){res.status(500).json({error:'تعذر تحميل المتابعة'});}});

app.use(express.static(new URL('../../',import.meta.url).pathname));
app.use('/admin',express.static(new URL('../../admin',import.meta.url).pathname));

app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'Internal server error'});});
requireEnv(); const server=app.listen(port,()=>console.log(`SOUQI MARKET backend listening on :${port}`));
process.on('SIGTERM',async()=>{server.close(async()=>{await pool.end();process.exit(0)});});
process.on('SIGINT',async()=>{server.close(async()=>{await pool.end();process.exit(0)});});
