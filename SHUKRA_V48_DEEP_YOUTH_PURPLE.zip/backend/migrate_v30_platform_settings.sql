CREATE TABLE IF NOT EXISTS platform_settings (
 key text PRIMARY KEY,
 value jsonb NOT NULL,
 updated_by uuid REFERENCES admin_users(id) ON DELETE SET NULL,
 updated_at timestamptz NOT NULL DEFAULT now()
);
