# PostgreSQL — SOUQI MARKET V32

هذه النسخة تربط الـBackend بقاعدة PostgreSQL حقيقية عبر مكتبة `pg`.

## تشغيل PostgreSQL محلياً بواسطة Docker
من مجلد المشروع:

```bash
docker compose -f docker-compose.postgres.yml up -d
```

غيّر `CHANGE_THIS_PASSWORD` في الملف إلى كلمة مرور قوية.

ثم في مجلد `backend`:

```bash
npm install
export DATABASE_URL="postgresql://souqi:YOUR_PASSWORD@localhost:5432/souqi_market"
npm run db:migrate
npm run db:check
npm start
```

على Windows PowerShell:

```powershell
$env:DATABASE_URL="postgresql://souqi:YOUR_PASSWORD@localhost:5432/souqi_market"
npm run db:migrate
npm run db:check
npm start
```

## الإنتاج
يمكن استخدام PostgreSQL مُدار من شركة الاستضافة بدلاً من Docker. ضع رابط الاتصال في `DATABASE_URL` فقط على الخادم، وليس داخل الواجهة الأمامية.

## ما يتم تخزينه
- المستخدمون والموظفون والصلاحيات.
- جلسات الإدارة وسجل التدقيق.
- الإعلانات والأسعار والعملات والصور.
- الشكاوى.
- عمليات الدفع وحالاتها.
- إعدادات المنصة.

## مهم
PostgreSQL ليس خدمة استضافة بحد ذاته؛ هو قاعدة البيانات. لكي تعمل SOUQI MARKET على الإنترنت تحتاج Backend مستضافاً وقاعدة PostgreSQL مستضافة، مع نسخ احتياطية ومفاتيح البيئة محفوظة على الخادم.
