SOUQI MARKET V88

Platform identity is petrol #155B63 only.
- Removed the legacy green/pistachio platform identity colors from the public shell.
- Updated header, logo, controls, hero, sections, map, frame, footer accent, PWA theme, and app icon.
- Preserved payment-card colors and compact card styling as requested.
- Preserved the global flags footer.
