SOUQI MARKET V87

Added a compact world-country flag strip to the bottom footer, separated clearly from "© 2026 SOUQI MARKET · جميع الحقوق محفوظة".
Included representative flags: Iraq, Saudi Arabia, UAE, Turkey, UK, USA, Germany, France, Italy, India, China, Japan, South Korea, Canada, Australia, Brazil.
Preserved the current petrol identity and compact payment-card styling.
